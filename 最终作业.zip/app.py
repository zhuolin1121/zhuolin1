# -*- coding: utf-8 -*-
"""
app.py
Flask 网页：展示双均线策略回测结果。
页面内容：策略信息、组合整体指标（vs 沪深300）、净值曲线图、个股明细表。

启动：python app.py
访问：http://127.0.0.1:5000/
"""

import os

import pandas as pd
from flask import Flask, render_template_string, send_file

from main import compute_backtest, plot_result, RESULT_PNG

app = Flask(__name__)

# 启动时跑一次回测并缓存结果（数据为静态历史数据，无需每次重算）
print('正在运行回测，请稍候...')
ROWS, PORT_STATS, BENCH_STATS, PORTFOLIO, BENCHMARK, ENGINE, STRATEGY = compute_backtest()
if not os.path.exists(RESULT_PNG):
    plot_result(PORTFOLIO, BENCHMARK, PORT_STATS, BENCH_STATS, ENGINE.initial_cash)
print('回测完成，启动 Web 服务。')

PAGE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>回测结果展示 · {{ strategy_name }}</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: "Microsoft YaHei", "PingFang SC", sans-serif;
               max-width: 1100px; margin: 0 auto; padding: 24px 20px 60px;
               color: #2b2b2b; background: #fafbfc; }
        h1 { font-size: 24px; margin: 0 0 4px; }
        h2 { font-size: 18px; margin: 32px 0 12px; padding-left: 10px;
             border-left: 4px solid #2c7fb8; }
        .subtitle { color: #888; font-size: 14px; margin-bottom: 20px; }

        .info-box { background: #fff; border: 1px solid #e3e9ef; border-radius: 10px;
                    padding: 16px 20px; font-size: 14px; line-height: 1.9; color: #555; }
        .info-box b { color: #2b2b2b; }

        table { border-collapse: collapse; width: 100%; background: #fff;
                border-radius: 10px; overflow: hidden;
                box-shadow: 0 1px 3px rgba(0,0,0,.06); }
        th, td { padding: 10px 14px; text-align: right; font-size: 14px;
                 border-bottom: 1px solid #eef2f5; }
        th { background: #2c7fb8; color: #fff; font-weight: 600; }
        td:first-child, th:first-child { text-align: left; }
        tr:last-child td { border-bottom: none; }
        tbody tr:hover { background: #f2f7fb; }

        .pos { color: #d73027; font-weight: 600; }   /* 涨：红 */
        .neg { color: #1a9850; font-weight: 600; }   /* 跌：绿 */
        .muted { color: #999; }

        .chart-box { background: #fff; border: 1px solid #e3e9ef;
                     border-radius: 10px; padding: 12px; }
        .chart-box img { width: 100%; display: block; border-radius: 6px; }

        .highlight { background: #f0f7ff; font-weight: 600; }
        footer { margin-top: 40px; color: #aaa; font-size: 12px; text-align: center; }
    </style>
</head>
<body>
    <h1>{{ strategy_name }} · 回测结果</h1>
    <div class="subtitle">A 股量化回测课程项目 · 数据区间 2019-01-02 ~ 2024-12-31</div>

    <h2>策略信息</h2>
    <div class="info-box">
        <b>策略规则：</b>短期均线（{{ short_ma }} 日）上穿长期均线（{{ long_ma }} 日）买入，下穿卖出<br>
        <b>组合构建：</b>10 只 A 股等权，初始资金 100 万元，前复权日线<br>
        <b>交易规则：</b>T+1，信号次日开盘价成交；佣金万 2.5（最低 5 元）双向，印花税万 5（卖出）；100 股整手交易<br>
        <b>业绩基准：</b>沪深300 指数（000300）
    </div>

    <h2>组合整体指标</h2>
    <table>
        <thead>
            <tr><th>指标</th><th>策略组合</th><th>沪深300 基准</th><th>超额</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>总收益率</td>
                <td class="{{ 'pos' if port.total_return >= 0 else 'neg' }}">{{ fmt_pct(port.total_return) }}</td>
                <td class="{{ 'pos' if bench.total_return >= 0 else 'neg' }}">{{ fmt_pct(bench.total_return) }}</td>
                <td class="{{ 'pos' if port.total_return - bench.total_return >= 0 else 'neg' }}">{{ fmt_pct(port.total_return - bench.total_return) }}</td>
            </tr>
            <tr>
                <td>年化收益率</td>
                <td class="{{ 'pos' if port.annual_return >= 0 else 'neg' }}">{{ fmt_pct(port.annual_return) }}</td>
                <td class="{{ 'pos' if bench.annual_return >= 0 else 'neg' }}">{{ fmt_pct(bench.annual_return) }}</td>
                <td class="{{ 'pos' if port.annual_return - bench.annual_return >= 0 else 'neg' }}">{{ fmt_pct(port.annual_return - bench.annual_return) }}</td>
            </tr>
            <tr>
                <td>最大回撤</td>
                <td class="neg">{{ fmt_pct(port.max_drawdown) }}</td>
                <td class="neg">{{ fmt_pct(bench.max_drawdown) }}</td>
                <td class="{{ 'pos' if port.max_drawdown - bench.max_drawdown >= 0 else 'neg' }}">{{ fmt_pct(port.max_drawdown - bench.max_drawdown) }}</td>
            </tr>
            <tr>
                <td>夏普比率</td>
                <td>{{ '%.2f' | format(port.sharpe) }}</td>
                <td>{{ '%.2f' | format(bench.sharpe) }}</td>
                <td class="{{ 'pos' if port.sharpe - bench.sharpe >= 0 else 'neg' }}">{{ '%+.2f' | format(port.sharpe - bench.sharpe) }}</td>
            </tr>
        </tbody>
    </table>

    <h2>净值曲线</h2>
    <div class="chart-box">
        <img src="/result.png?v={{ cache_id }}" alt="组合 vs 沪深300 净值曲线">
    </div>

    <h2>个股明细</h2>
    <table>
        <thead>
            <tr><th>代码</th><th>累计收益</th><th>年化收益</th><th>最大回撤</th>
                <th>夏普</th><th>交易次数</th><th>胜率</th></tr>
        </thead>
        <tbody>
            {% for r in rows %}
            <tr>
                <td>{{ r.code }}</td>
                <td class="{{ 'pos' if r.total_return >= 0 else 'neg' }}">{{ fmt_pct(r.total_return) }}</td>
                <td class="{{ 'pos' if r.annual_return >= 0 else 'neg' }}">{{ fmt_pct(r.annual_return) }}</td>
                <td class="neg">{{ fmt_pct(r.max_drawdown) }}</td>
                <td>{{ '%.2f' | format(r.sharpe) }}</td>
                <td>{{ r.n_trades | int }}</td>
                <td>{{ fmt_pct(r.win_rate) if r.win_rate == r.win_rate else '-' }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>

    <footer>由 Flask 驱动 · 数据来自 akshare · 回测引擎支持 T+1 与交易成本</footer>
</body>
</html>
"""


def fmt_pct(x: float) -> str:
    return f'{x:.2%}'


@app.route('/')
def index():
    return render_template_string(
        PAGE,
        strategy_name=STRATEGY.name,
        short_ma=STRATEGY.short_window,
        long_ma=STRATEGY.long_window,
        rows=ROWS,
        port=PORT_STATS,
        bench=BENCH_STATS,
        fmt_pct=fmt_pct,
        cache_id=int(os.path.getmtime(RESULT_PNG)),
    )


@app.route('/result.png')
def result_png():
    return send_file(RESULT_PNG, mimetype='image/png')


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=False)
