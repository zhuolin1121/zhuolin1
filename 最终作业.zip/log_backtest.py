# -*- coding: utf-8 -*-
"""
log_backtest.py
1. 依次运行三个策略（趋势跟踪/均值回归/多因子）的 10 股等权组合回测，
   把每次回测的时间、策略名称、参数、总收益率、最大回撤等核心指标
   追加记录到 backtest_log.csv（每次运行追加一行，可多次积累）
2. 对 data/ 目录下全部 CSV 做数据校验（缺失值/异常值），
   生成 数据校验报告.txt
"""

import os
from datetime import datetime

import numpy as np
import pandas as pd

from backtest.engine import BacktestEngine, BacktestResult
from strategies.trend_following import TrendFollowingStrategy
from strategies.mean_reversion import MeanReversionStrategy
from strategies.multi_factor import MultiFactorStrategy

DATA_DIR = 'data'
INDEX_CODE = '000300'
LOG_CSV = 'backtest_log.csv'
VALIDATION_TXT = '数据校验报告.txt'

# (策略类, 构造参数)
STRATEGIES = [
    (TrendFollowingStrategy, dict(short_window=5, long_window=20)),
    (MeanReversionStrategy, dict(window=20, num_std=2.0)),
    (MultiFactorStrategy, dict()),
]


# ---------------- 回测日志 ----------------
def run_portfolio(strategy) -> dict:
    """用给定策略跑 10 股等权组合，返回组合级指标。"""
    engine = BacktestEngine()
    codes = sorted(f[:-4] for f in os.listdir(DATA_DIR)
                   if f.endswith('.csv') and f[:-4] != INDEX_CODE)

    equity_list, total_trades, win_rates = [], 0, []
    for code in codes:
        df = pd.read_csv(os.path.join(DATA_DIR, f'{code}.csv'),
                         parse_dates=['date'])
        signals = strategy.generate_signals(df)
        result = engine.run(df, signals, name=code)
        equity_list.append(result.equity)
        s = result.stats()
        total_trades += s['n_trades']
        if not np.isnan(s['win_rate']):
            win_rates.append(s['win_rate'])

    portfolio = pd.concat(equity_list, axis=1).mean(axis=1)
    stats = BacktestResult(name='组合', equity=portfolio, trades=[]).stats()
    stats['n_trades'] = total_trades
    stats['win_rate'] = np.mean(win_rates) if win_rates else np.nan
    return stats


def append_log():
    """跑三个策略并追加到 backtest_log.csv。"""
    rows = []
    for cls, params in STRATEGIES:
        strategy = cls(**params)
        param_str = ','.join(f'{k}={v}' for k, v in params.items()) or '默认'
        stats = run_portfolio(strategy)
        rows.append({
            '时间': f'{datetime.now():%Y-%m-%d %H:%M:%S}',
            '策略': strategy.name,
            '参数': param_str,
            '总收益率': f"{stats['total_return']:.2%}",
            '年化收益率': f"{stats['annual_return']:.2%}",
            '最大回撤': f"{stats['max_drawdown']:.2%}",
            '夏普比率': f"{stats['sharpe']:.2f}",
            '总交易次数': stats['n_trades'],
            '平均胜率': (f"{stats['win_rate']:.2%}"
                       if not np.isnan(stats['win_rate']) else '-'),
        })
        print(f"[OK] {strategy.name:<14} 总收益率 {stats['total_return']:+.2%}  "
              f"最大回撤 {stats['max_drawdown']:.2%}  夏普 {stats['sharpe']:.2f}")

    df_new = pd.DataFrame(rows)
    header = not os.path.exists(LOG_CSV)
    df_new.to_csv(LOG_CSV, mode='a', header=header, index=False,
                  encoding='utf-8-sig')
    print(f'\n回测记录已追加 -> {LOG_CSV}（本次新增 {len(rows)} 条）')


# ---------------- 数据校验 ----------------
def validate_data() -> str:
    """校验 data/ 下全部 CSV，返回报告文本。"""
    files = sorted(f for f in os.listdir(DATA_DIR) if f.endswith('.csv'))
    now = f'{datetime.now():%Y-%m-%d %H:%M:%S}'

    lines = [
        '数据校验报告',
        '=' * 50,
        f'生成时间: {now}',
        f'数据目录: {DATA_DIR}/（共 {len(files)} 个文件）',
        '',
        '校验项目：',
        '  1. 缺失值（各列 NaN 数量）',
        '  2. 重复日期',
        '  3. 价格非正（open/high/low/close <= 0）',
        '  4. 成交量为负',
        '  5. 价格逻辑异常（high < low，或 high/low 未包住开收盘）',
        '  6. 单日涨跌幅超过 21%（超出 A 股涨跌停幅度视为异常）',
        '',
        '-' * 50,
        '逐文件校验结果：',
        '',
    ]

    all_pass = True
    for f in files:
        code = f[:-4]
        df = pd.read_csv(os.path.join(DATA_DIR, f), parse_dates=['date'])

        n_rows = len(df)
        date_min, date_max = df['date'].min().date(), df['date'].max().date()
        n_nan = int(df.isna().sum().sum())
        n_dup = int(df['date'].duplicated().sum())
        price_cols = ['open', 'high', 'low', 'close']
        n_bad_price = int((df[price_cols] <= 0).sum().sum())
        n_neg_vol = int((df['volume'] < 0).sum())
        n_logic = int((df['high'] < df['low']).sum()
                      + (df['high'] < df[['open', 'close']].max(axis=1)).sum()
                      + (df['low'] > df[['open', 'close']].min(axis=1)).sum())
        n_jump = int((df['close'].pct_change().abs() > 0.21).sum())

        ok = (n_nan == 0 and n_dup == 0 and n_bad_price == 0
              and n_neg_vol == 0 and n_logic == 0 and n_jump == 0)
        all_pass &= ok

        lines.append(f'[{code}] {n_rows} 行，区间 {date_min} ~ {date_max}')
        lines.append(f'  缺失值 {n_nan} | 重复日期 {n_dup} | 价格非正 {n_bad_price} | '
                     f'负成交量 {n_neg_vol} | 逻辑异常 {n_logic} | 涨跌幅超21% {n_jump}'
                     f'  -> {"通过" if ok else "存在异常"}')
        lines.append('')

    lines.append('-' * 50)
    if all_pass:
        lines.append('总体结论：全部数据文件校验通过，未发现缺失值和异常值，数据可用于回测。')
    else:
        lines.append('总体结论：部分文件存在上述异常，请先处理后再用于回测。')
    return '\n'.join(lines) + '\n'


def main():
    print('===== 1. 运行回测并记录日志 =====')
    append_log()

    print('\n===== 2. 数据校验 =====')
    report = validate_data()
    with open(VALIDATION_TXT, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f'数据校验报告已生成 -> {VALIDATION_TXT}')
    # 把总体结论也打印到屏幕
    print(report.strip().split('\n')[-1])


if __name__ == '__main__':
    main()
