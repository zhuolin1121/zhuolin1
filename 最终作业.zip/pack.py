# -*- coding: utf-8 -*-
"""
pack.py
把项目根目录下的所有文件打包为 最终作业.zip（保存在根目录）。
排除：__pycache__ 文件夹、压缩包自身。
"""

import os
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
ZIP_NAME = '最终作业.zip'


def main():
    zip_path = os.path.join(ROOT, ZIP_NAME)
    if os.path.exists(zip_path):   # 已存在则先删除，避免旧内容残留
        os.remove(zip_path)

    count = 0
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(ROOT):
            dirnames[:] = [d for d in dirnames if d != '__pycache__']
            for fn in filenames:
                fp = os.path.abspath(os.path.join(dirpath, fn))
                if fp == zip_path:
                    continue
                arcname = os.path.relpath(fp, ROOT)
                zf.write(fp, arcname)
                count += 1
                print('  +', arcname)

    size_kb = os.path.getsize(zip_path) / 1024
    print(f'\n打包完成 -> {ZIP_NAME}（共 {count} 个文件，{size_kb:.1f} KB）')


if __name__ == '__main__':
    main()
