# A 股量化回测系统

基于 AkShare 数据与自建回测引擎的 A 股量化回测项目：下载 10 只股票与沪深300 指数
2019–2024 年前复权日线数据，实现支持 T+1 与交易成本（佣金 + 印花税）的回测引擎，
内置双均线趋势跟踪、布林带均值回归、多因子三个策略，并通过 Flask 网页展示回测结果。

## 回测结果摘要（双均线策略，等权组合）

| 指标 | 策略组合 | 沪深300 基准 |
| --- | ---: | ---: |
| 总收益率 | 49.13% | 32.51% |
| 年化收益率 | 7.16% | 4.99% |
| 最大回撤 | -32.07% | -45.60% |
| 夏普比率 | 0.53 | 0.35 |

## 目录结构

```
.
├── backtest/               # 回测引擎
│   └── engine.py           #   单标的引擎：T+1、佣金、印花税、整手交易
├── strategies/             # 策略库
│   ├── trend_following.py  #   双均线趋势跟踪（金叉买、死叉卖）
│   ├── mean_reversion.py   #   布林带均值回归
│   └── multi_factor.py     #   多因子（动量+趋势+量能）
├── data/                   # 行情数据（11 个 CSV：10 股票 + 000300 指数）
├── output/                 # 回测结果
│   └── result.png          #   组合 vs 沪深300 净值曲线
├── records/                # 实验记录
│   └── report.md           #   回测指标报告
├── demo/                   # 演示截图
├── download_data.py        # 数据下载脚本（AkShare）
├── calc_returns.py         # 日收益率计算脚本
├── main.py                 # 回测主程序
├── app.py                  # Flask 网页展示
├── pack.py                 # 项目打包脚本
├── requirements.txt        # 依赖清单
└── returns_daily.csv       # 各标的日收益率（calc_returns.py 生成）
```

## 环境安装

```bash
pip install -r requirements.txt
```

主要依赖：akshare、pandas、numpy、matplotlib、flask。

## 运行方式

```bash
python download_data.py   # 1. 下载数据到 data/（已有数据可跳过）
python calc_returns.py    # 2. 可选：计算日收益率，生成 returns_daily.csv
python main.py            # 3. 运行回测：打印指标，生成 output/result.png 和 records/report.md
python app.py             # 4. 启动网页：浏览器访问 http://127.0.0.1:5000/
python pack.py            # 5. 可选：打包整个项目为 最终作业.zip
```
