# -*- coding: utf-8 -*-
"""
calc_returns.py
读取 data/ 目录下的 CSV 文件，计算每只股票的日收益率，
合并保存为 returns_daily.csv，并打印区间累计收益率汇总。
"""

import glob
import os

import pandas as pd

DATA_DIR = 'data'
OUTPUT_FILE = 'returns_daily.csv'


def calc_daily_return(path: str) -> pd.Series:
    """读取单个 CSV，返回以 date 为索引的日收益率序列（收盘价简单收益率）。"""
    code = os.path.splitext(os.path.basename(path))[0]
    df = pd.read_csv(path, parse_dates=['date'])
    df = df.sort_values('date').reset_index(drop=True)
    ret = df['close'].pct_change()
    return pd.Series(ret.values, index=df['date'], name=code)


def main():
    files = sorted(glob.glob(os.path.join(DATA_DIR, '*.csv')))
    if not files:
        print(f'{DATA_DIR}/ 目录下没有找到 CSV 文件')
        return

    # 按日期对齐，合并成宽表：行=日期，列=代码
    returns = pd.concat([calc_daily_return(f) for f in files], axis=1)
    returns.index.name = 'date'
    returns.to_csv(OUTPUT_FILE, float_format='%.6f', encoding='utf-8-sig')
    print(f'日收益率已保存 -> {OUTPUT_FILE}  (形状: {returns.shape})\n')

    # 区间累计收益率汇总：(1+r1)*(1+r2)*... - 1
    summary = (1 + returns.fillna(0)).prod() - 1
    summary = summary.sort_values(ascending=False)
    print('区间累计收益率（2019-01-02 ~ 2024-12-31）:')
    for code, r in summary.items():
        print(f'  {code}: {r:>8.2%}')


if __name__ == '__main__':
    main()
