# -*- coding: utf-8 -*-
"""
optimize.py
双均线策略参数寻优（网格搜索 Grid Search）：
1. 样本内（2019-01-01 ~ 2022-12-31）：遍历短均线 5-10、长均线 20-60，
   以 10 只股票等权平均总收益率为目标函数，选出最优参数组合
2. 样本外（2023-01-01 ~ 2024-12-31）：用最优参数做样本外验证
3. 结果打印到屏幕，并保存最优参数到 params.txt
"""

import os
from datetime import datetime

import pandas as pd

from backtest.engine import BacktestEngine
from strategies.trend_following import TrendFollowingStrategy

# ---------------- 配置 ----------------
DATA_DIR = 'data'
STOCK_LIST = [
    '600519', '601318', '601398', '600900', '000002',
    '600276', '002415', '002594', '600111', '601888',
]
STOCK_NAMES = {
    '600519': '贵州茅台', '601318': '中国平安', '601398': '工商银行',
    '600900': '长江电力', '000002': '万科A',   '600276': '恒瑞医药',
    '002415': '海康威视', '002594': '比亚迪',   '600111': '北方稀土',
    '601888': '中国中免',
}

SHORT_RANGE = range(5, 11)    # 短均线 5~10
LONG_RANGE = range(20, 61)    # 长均线 20~60

IS_END = '2022-12-31'         # 样本内截止
OOS_START = '2023-01-01'      # 样本外起始

PARAMS_FILE = 'params.txt'


def load_data():
    """读取全部股票数据。"""
    data = {}
    for code in STOCK_LIST:
        path = os.path.join(DATA_DIR, f'{code}.csv')
        df = pd.read_csv(path, parse_dates=['date'])
        data[code] = df.sort_values('date').reset_index(drop=True)
    return data


def run_one(df: pd.DataFrame, short_w: int, long_w: int) -> float:
    """对单只股票的一段数据跑一次回测，返回总收益率（小数）。"""
    strategy = TrendFollowingStrategy(short_window=short_w, long_window=long_w)
    signals = strategy.generate_signals(df)
    engine = BacktestEngine()
    result = engine.run(df, signals)
    return result.stats()['total_return']


def evaluate(data, short_w: int, long_w: int, period: str):
    """用一组参数跑全部股票，返回 (平均收益率, {代码: 收益率})。"""
    rets = {}
    for code, df in data.items():
        if period == 'is':
            sub = df[df['date'] <= IS_END].reset_index(drop=True)
        else:
            sub = df[df['date'] >= OOS_START].reset_index(drop=True)
        rets[code] = run_one(sub, short_w, long_w)
    avg = sum(rets.values()) / len(rets)
    return avg, rets


def main():
    data = load_data()

    combos = [(s, l) for s in SHORT_RANGE for l in LONG_RANGE if s < l]
    print(f'参数组合共 {len(combos)} 组（短均线 5-10 × 长均线 20-60）')
    print(f'开始样本内网格搜索（2019-01-01 ~ {IS_END}）...\n')

    # ---------- 样本内网格搜索 ----------
    results = []  # (平均收益率, 短均线, 长均线)
    for i, (s, l) in enumerate(combos, 1):
        avg, _ = evaluate(data, s, l, period='is')
        results.append((avg, s, l))
        if i % 50 == 0 or i == len(combos):
            print(f'  进度: {i}/{len(combos)}')

    results.sort(reverse=True)
    print('\n样本内平均总收益率 Top 5：')
    for avg, s, l in results[:5]:
        print(f'  短均线={s:>2}, 长均线={l:>2}  ->  {avg:+.2%}')

    best_avg_is, best_s, best_l = results[0]
    print(f'\n>>> 最优参数：短均线={best_s}, 长均线={best_l}'
          f'（样本内平均总收益率 {best_avg_is:+.2%}）')

    # ---------- 样本外验证 ----------
    print(f'\n样本外验证（{OOS_START} ~ 2024-12-31）...')
    best_avg_oos, oos_detail = evaluate(data, best_s, best_l, period='oos')
    print(f'最优参数样本外平均总收益率: {best_avg_oos:+.2%}')
    print('样本外个股明细：')
    for code in STOCK_LIST:
        name = STOCK_NAMES.get(code, '')
        print(f'  {code} {name:<4}: {oos_detail[code]:+.2%}')

    # ---------- 默认参数 (5, 20) 对照 ----------
    d_is, _ = evaluate(data, 5, 20, period='is')
    d_oos, _ = evaluate(data, 5, 20, period='oos')
    print(f'\n对照（默认参数 5/20）：样本内 {d_is:+.2%}，样本外 {d_oos:+.2%}')

    # ---------- 保存 params.txt ----------
    lines = [
        '双均线策略参数寻优结果',
        '=' * 40,
        f'生成时间: {datetime.now():%Y-%m-%d %H:%M:%S}',
        '数据来源: data/ 目录本地 CSV（AkShare，前复权）',
        f'股票池: {len(STOCK_LIST)} 只 A 股，等权平均',
        '',
        '搜索方法: 网格搜索 (Grid Search)',
        f'短均线范围: {SHORT_RANGE.start} ~ {SHORT_RANGE.stop - 1}',
        f'长均线范围: {LONG_RANGE.start} ~ {LONG_RANGE.stop - 1}',
        f'参数组合数: {len(combos)}',
        '',
        f'样本内区间: 2019-01-01 ~ {IS_END}',
        f'样本外区间: {OOS_START} ~ 2024-12-31',
        '',
        f'最优参数: 短均线 = {best_s}, 长均线 = {best_l}',
        f'样本内平均总收益率: {best_avg_is:+.2%}',
        f'样本外平均总收益率: {best_avg_oos:+.2%}',
        '',
        '对照（默认参数 5/20）:',
        f'  样本内: {d_is:+.2%}',
        f'  样本外: {d_oos:+.2%}',
    ]
    with open(PARAMS_FILE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    print(f'\n最优参数已保存 -> {PARAMS_FILE}')


if __name__ == '__main__':
    main()
