# -*- coding: utf-8 -*-
"""
backtest/engine.py
单标的回测引擎。

规则：
- T+1：当日买入的份额当日不可卖出，最早次日才能卖出。
- 信号在 T 日收盘后产生，于 T+1 日开盘价成交（避免使用未来数据）。
- 费用：佣金（买卖双向，默认万 2.5，最低 5 元）+ 印花税（仅卖出收，默认万 5）。
- A 股整手交易：买入数量为 100 股的整数倍，卖出时全部卖出。
"""

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class TradeRecord:
    date: pd.Timestamp
    side: str        # 'BUY' / 'SELL'
    price: float
    shares: int
    fee: float


@dataclass
class BacktestResult:
    name: str
    equity: pd.Series                 # 每日收盘后总资产（含持仓市值）
    trades: list = field(default_factory=list)

    def stats(self) -> dict:
        n = len(self.equity)
        total_return = self.equity.iloc[-1] / self.equity.iloc[0] - 1
        annual_return = (1 + total_return) ** (252 / n) - 1 if n > 1 else 0.0

        cummax = self.equity.cummax()
        max_drawdown = (self.equity / cummax - 1).min()

        daily_ret = self.equity.pct_change().dropna()
        sharpe = (daily_ret.mean() / daily_ret.std() * np.sqrt(252)
                  if daily_ret.std() > 0 else 0.0)

        # 配对计算胜率（BUY -> SELL）
        wins, closed = 0, 0
        buy_cost = None
        for t in self.trades:
            if t.side == 'BUY':
                buy_cost = t.price * t.shares + t.fee
            elif t.side == 'SELL' and buy_cost is not None:
                pnl = t.price * t.shares - t.fee - buy_cost
                closed += 1
                wins += pnl > 0
                buy_cost = None
        win_rate = wins / closed if closed > 0 else np.nan

        return {
            'total_return': total_return,
            'annual_return': annual_return,
            'max_drawdown': max_drawdown,
            'sharpe': sharpe,
            'n_trades': closed,
            'win_rate': win_rate,
        }


class BacktestEngine:
    def __init__(self, initial_cash: float = 1_000_000,
                 commission: float = 0.00025,
                 min_commission: float = 5.0,
                 stamp_tax: float = 0.0005,
                 lot_size: int = 100):
        self.initial_cash = initial_cash
        self.commission = commission        # 佣金率（双向）
        self.min_commission = min_commission
        self.stamp_tax = stamp_tax          # 印花税（仅卖出）
        self.lot_size = lot_size

    def _buy_fee(self, amount: float) -> float:
        return max(amount * self.commission, self.min_commission)

    def _sell_fee(self, amount: float) -> float:
        return max(amount * self.commission, self.min_commission) + amount * self.stamp_tax

    def run(self, df: pd.DataFrame, signals: pd.Series, name: str = '') -> BacktestResult:
        """
        df: 含 date, open, high, low, close, volume 的日线数据（按日期升序）。
        signals: 与 df 等长的序列，1=买入信号，-1=卖出信号，0=无操作。
                 信号在当日收盘后产生，下一交易日以开盘价成交。
        """
        df = df.reset_index(drop=True)
        signals = signals.fillna(0).astype(int).reset_index(drop=True)

        cash, shares, buy_date = self.initial_cash, 0, None
        equity_curve, trades = [], []

        for i in range(len(df)):
            row = df.iloc[i]
            date, open_p, close_p = row['date'], row['open'], row['close']

            if i > 0:
                sig = signals.iloc[i - 1]  # 昨日收盘产生的信号，今日开盘执行

                if sig == 1 and shares == 0:
                    n = int(cash / (open_p * self.lot_size)) * self.lot_size
                    while n > 0 and n * open_p + self._buy_fee(n * open_p) > cash:
                        n -= self.lot_size
                    if n > 0:
                        amount = n * open_p
                        fee = self._buy_fee(amount)
                        cash -= amount + fee
                        shares, buy_date = n, date
                        trades.append(TradeRecord(date, 'BUY', open_p, n, fee))

                elif sig == -1 and shares > 0:
                    if date == buy_date:
                        # T+1：当日买入不可当日卖出，顺延（信号交易下次开盘执行，此处为防御性处理）
                        pass
                    else:
                        amount = shares * open_p
                        fee = self._sell_fee(amount)
                        cash += amount - fee
                        trades.append(TradeRecord(date, 'SELL', open_p, shares, fee))
                        shares, buy_date = 0, None

            equity_curve.append(cash + shares * close_p)

        equity = pd.Series(equity_curve, index=df['date'], name='equity')
        return BacktestResult(name=name, equity=equity, trades=trades)
