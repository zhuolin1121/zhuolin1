# -*- coding: utf-8 -*-
"""
main.py
主程序：
1. 读取 data/ 下全部 11 个 CSV（10 只股票 + 沪深300 指数）；
2. 对 10 只股票运行双均线趋势跟踪策略，构建等权组合；
3. 打印每只股票的回测指标与组合整体的总收益率、最大回撤、夏普比率；
4. 绘制组合净值曲线（含沪深300 基准对比），保存为 result.png。

运行：python main.py
"""

import os

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

from backtest.engine import BacktestEngine, BacktestResult
from strategies.trend_following import TrendFollowingStrategy

DATA_DIR = 'data'
INDEX_CODE = '000300'       # 沪深300，作为基准

OUTPUT_DIR = 'output'       # 回测结果输出目录
RECORDS_DIR = 'records'     # 实验记录目录
RESULT_PNG = os.path.join(OUTPUT_DIR, 'result.png')
REPORT_MD = os.path.join(RECORDS_DIR, 'report.md')

# 中文字体，避免图中中文乱码
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


def load_data(code: str) -> pd.DataFrame:
    df = pd.read_csv(os.path.join(DATA_DIR, f'{code}.csv'), parse_dates=['date'])
    return df.sort_values('date').reset_index(drop=True)


def compute_backtest():
    """运行回测。

    返回 (rows, port_stats, bench_stats, portfolio, benchmark, engine, strategy)：
    rows        每只股票指标字典组成的列表
    port_stats  等权组合指标
    bench_stats 沪深300 基准指标
    portfolio   组合净值序列（绝对金额）
    benchmark   基准净值序列（绝对金额）
    """
    codes = sorted(f[:-4] for f in os.listdir(DATA_DIR)
                   if f.endswith('.csv') and f[:-4] != INDEX_CODE)

    strategy = TrendFollowingStrategy(short_window=5, long_window=20)
    engine = BacktestEngine()

    # 逐股回测，收集净值曲线（等权组合 = 各股净值的平均）
    equity_list, rows = [], []
    for code in codes:
        df = load_data(code)
        signals = strategy.generate_signals(df)
        result = engine.run(df, signals, name=code)
        equity_list.append(result.equity)

        s = result.stats()
        s['code'] = code
        rows.append(s)

    # 等权组合净值
    portfolio = pd.concat(equity_list, axis=1).mean(axis=1)
    port_stats = BacktestResult(name='组合', equity=portfolio, trades=[]).stats()

    # 基准：沪深300 归一化到相同起始资金
    index_df = load_data(INDEX_CODE)
    benchmark = (index_df.set_index('date')['close']
                 .reindex(portfolio.index).ffill())
    benchmark = benchmark / benchmark.iloc[0] * engine.initial_cash
    bench_stats = BacktestResult(name='沪深300', equity=benchmark, trades=[]).stats()

    return rows, port_stats, bench_stats, portfolio, benchmark, engine, strategy


def plot_result(portfolio, benchmark, port_stats, bench_stats,
                initial_cash, path: str = RESULT_PNG):
    """绘制组合 vs 基准净值曲线并保存图片。"""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(portfolio.index, portfolio / initial_cash,
            label=f"双均线策略组合 ({port_stats['total_return']:.1%})", linewidth=1.5)
    ax.plot(benchmark.index, benchmark / initial_cash,
            label=f"沪深300 ({bench_stats['total_return']:.1%})", linewidth=1.5, alpha=0.85)
    ax.axhline(1.0, color='gray', linestyle='--', linewidth=0.8)
    ax.set_title('双均线趋势跟踪策略 等权组合净值曲线（2019-2024，前复权）')
    ax.set_xlabel('日期')
    ax.set_ylabel('净值')
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def write_report(rows, port_stats, bench_stats, strategy, engine,
                 path: str = REPORT_MD):
    """把回测指标写入 Markdown 实验报告。"""
    os.makedirs(os.path.dirname(path), exist_ok=True)

    def pct(x):
        return f'{x:.2%}'

    lines = [
        '# 回测实验报告',
        '',
        f'- 策略：{strategy.name}（短期均线 {strategy.short_window} 日 / '
        f'长期均线 {strategy.long_window} 日，金叉买入、死叉卖出）',
        f'- 标的：10 只 A 股等权组合，初始资金 {engine.initial_cash:,.0f} 元',
        '- 区间：2019-01-02 ~ 2024-12-31（前复权日线）',
        '- 交易规则：T+1，信号次日开盘价成交，佣金万 2.5（最低 5 元）双向，'
        '印花税万 5（卖出），100 股整手交易',
        '- 基准：沪深300（000300）',
        '',
        '## 组合整体指标',
        '',
        '| 指标 | 策略组合 | 沪深300 基准 |',
        '| --- | ---: | ---: |',
        f"| 总收益率 | {pct(port_stats['total_return'])} "
        f"| {pct(bench_stats['total_return'])} |",
        f"| 年化收益率 | {pct(port_stats['annual_return'])} "
        f"| {pct(bench_stats['annual_return'])} |",
        f"| 最大回撤 | {pct(port_stats['max_drawdown'])} "
        f"| {pct(bench_stats['max_drawdown'])} |",
        f"| 夏普比率 | {port_stats['sharpe']:.2f} "
        f"| {bench_stats['sharpe']:.2f} |",
        '',
        '净值曲线见 `output/result.png`。',
        '',
        '## 个股明细',
        '',
        '| 代码 | 累计收益 | 年化收益 | 最大回撤 | 夏普 | 交易次数 | 胜率 |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |',
    ]
    for r in rows:
        win = pct(r['win_rate']) if pd.notna(r['win_rate']) else '-'
        lines.append(
            f"| {r['code']} | {pct(r['total_return'])} "
            f"| {pct(r['annual_return'])} | {pct(r['max_drawdown'])} "
            f"| {r['sharpe']:.2f} | {int(r['n_trades'])} | {win} |")

    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')


def main():
    rows, port_stats, bench_stats, portfolio, benchmark, engine, strategy = compute_backtest()

    print(f'策略：{strategy.name}（等权组合，初始资金 {engine.initial_cash:,.0f}）')
    print('-' * 70)
    print(f'{"代码":<8}{"累计收益":>10}{"年化收益":>10}{"最大回撤":>10}'
          f'{"夏普":>8}{"交易次数":>8}{"胜率":>8}')
    for r in rows:
        win = f"{r['win_rate']:.1%}" if pd.notna(r['win_rate']) else '  -  '
        print(f"{r['code']:<8}{r['total_return']:>10.2%}{r['annual_return']:>10.2%}"
              f"{r['max_drawdown']:>10.2%}{r['sharpe']:>8.2f}"
              f"{int(r['n_trades']):>8}{win:>8}")

    print('=' * 70)
    print('回测最终结果（等权组合 vs 沪深300）：')
    print(f"  组合总收益率 : {port_stats['total_return']:.2%}"
          f"（基准 {bench_stats['total_return']:.2%}）")
    print(f"  组合最大回撤 : {port_stats['max_drawdown']:.2%}"
          f"（基准 {bench_stats['max_drawdown']:.2%}）")
    print(f"  组合夏普比率 : {port_stats['sharpe']:.2f}"
          f"（基准 {bench_stats['sharpe']:.2f}）")

    plot_result(portfolio, benchmark, port_stats, bench_stats, engine.initial_cash)
    print(f'\n净值曲线已保存 -> {RESULT_PNG}')

    write_report(rows, port_stats, bench_stats, strategy, engine)
    print(f'实验报告已保存 -> {REPORT_MD}')


if __name__ == '__main__':
    main()
