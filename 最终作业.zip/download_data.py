# -*- coding: utf-8 -*-
"""
download_data.py
使用 akshare 下载 A 股 10 只股票 + 沪深300 指数的历史日线数据（前复权），
统一列名为 date, open, high, low, close, volume，保存为 CSV 到 data/ 目录。
"""

import os
import time

import akshare as ak
import pandas as pd

# ---------------- 配置 ----------------
STOCK_LIST = [
    '600519', '601318', '601398', '600900', '000002',
    '600276', '002415', '002594', '600111', '601888',
]
INDEX_CODE = '000300'   # 沪深300

START_DATE = '20190101'
END_DATE = '20241231'

DATA_DIR = 'data'

COLUMNS = ['date', 'open', 'high', 'low', 'close', 'volume']

# akshare 返回的中文列名 -> 统一英文列名
COLUMN_MAP = {
    '日期': 'date',
    '开盘': 'open',
    '最高': 'high',
    '最低': 'low',
    '收盘': 'close',
    '成交量': 'volume',
}


def normalize(df: pd.DataFrame) -> pd.DataFrame:
    """统一列名与日期格式，只保留所需列，并按时间范围过滤。"""
    df = df.rename(columns=COLUMN_MAP)
    df = df[COLUMNS].copy()
    df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
    df = df[(df['date'] >= '2019-01-01') & (df['date'] <= '2024-12-31')]
    return df.reset_index(drop=True)


def _symbol_with_exchange(code: str) -> str:
    """给 6 位代码加交易所前缀（新浪接口需要）：6 开头为 sh，其余为 sz。"""
    return ('sh' if code.startswith('6') else 'sz') + code


def download_stock(code: str) -> pd.DataFrame:
    """下载单只 A 股日线数据（前复权 qfq）。

    主数据源为东方财富；若被限流或失败，自动切换新浪源。
    """
    try:
        df = ak.stock_zh_a_hist(
            symbol=code,
            period='daily',
            start_date=START_DATE,
            end_date=END_DATE,
            adjust='qfq',
        )
    except Exception:
        time.sleep(1)
        df = ak.stock_zh_a_daily(
            symbol=_symbol_with_exchange(code),
            start_date=START_DATE,
            end_date=END_DATE,
            adjust='qfq',
        )
    return normalize(df)


def download_index(code: str) -> pd.DataFrame:
    """下载指数日线数据（指数无复权概念，用原始行情）。

    主数据源为东方财富；若被限流或失败，自动切换新浪源。
    """
    try:
        df = ak.index_zh_a_hist(
            symbol=code,
            period='daily',
            start_date=START_DATE,
            end_date=END_DATE,
        )
    except Exception:
        time.sleep(1)
        # 沪深300 等中证系列指数在新浪源中的代码为 sh 前缀
        df = ak.stock_zh_index_daily(symbol='sh' + code)
    return normalize(df)


def main():
    os.makedirs(DATA_DIR, exist_ok=True)

    tasks = [('stock', c) for c in STOCK_LIST] + [('index', INDEX_CODE)]

    for kind, code in tasks:
        path = os.path.join(DATA_DIR, f'{code}.csv')
        try:
            if kind == 'stock':
                df = download_stock(code)
            else:
                df = download_index(code)
            df.to_csv(path, index=False, encoding='utf-8-sig')
            print(f'[OK]   {code}: {len(df)} 行 -> {path}')
        except Exception as e:
            print(f'[FAIL] {code}: {e}')
        time.sleep(1)  # 防止请求过快被接口封禁


if __name__ == '__main__':
    main()
