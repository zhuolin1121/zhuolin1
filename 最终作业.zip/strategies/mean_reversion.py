# -*- coding: utf-8 -*-
"""
strategies/mean_reversion.py
均值回归策略：布林带。
收盘价跌破下轨（超跌）-> 买入信号；反弹回到中轨（均线）上方 -> 卖出信号。
"""

import pandas as pd


class MeanReversionStrategy:
    name = '均值回归(布林带)'

    def __init__(self, window: int = 20, num_std: float = 2.0):
        self.window = window
        self.num_std = num_std

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        close = df['close']
        mid = close.rolling(self.window).mean()
        std = close.rolling(self.window).std()
        lower = mid - self.num_std * std

        buy = (close < lower) & (close.shift(1) >= lower.shift(1))   # 跌破下轨
        sell = (close > mid) & (close.shift(1) <= mid.shift(1))      # 回到中轨上方

        signals = pd.Series(0, index=df.index)
        signals[buy] = 1
        signals[sell] = -1
        return signals
