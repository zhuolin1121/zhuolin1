# -*- coding: utf-8 -*-
"""
strategies/trend_following.py
趋势跟踪策略：双均线（金叉买入，死叉卖出）。
短期均线上穿长期均线 -> 买入信号；下穿 -> 卖出信号。
"""

import pandas as pd


class TrendFollowingStrategy:
    name = '趋势跟踪(双均线)'

    def __init__(self, short_window: int = 5, long_window: int = 20):
        if short_window >= long_window:
            raise ValueError('short_window 必须小于 long_window')
        self.short_window = short_window
        self.long_window = long_window

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        close = df['close']
        ma_short = close.rolling(self.short_window).mean()
        ma_long = close.rolling(self.long_window).mean()

        golden_cross = (ma_short > ma_long) & (ma_short.shift(1) <= ma_long.shift(1))
        death_cross = (ma_short < ma_long) & (ma_short.shift(1) >= ma_long.shift(1))

        signals = pd.Series(0, index=df.index)
        signals[golden_cross] = 1
        signals[death_cross] = -1
        return signals
