# -*- coding: utf-8 -*-
"""
strategies/multi_factor.py
多因子策略：动量 + 趋势 + 量能三个因子打分。
- 动量因子：20 日收益率 > 0
- 趋势因子：收盘价 > 60 日均线
- 量能因子：5 日均量 > 20 日均量（资金活跃）
综合得分 >= 2 时产生买入信号，得分 <= 1 时产生卖出信号。
"""

import pandas as pd


class MultiFactorStrategy:
    name = '多因子(动量+趋势+量能)'

    def __init__(self, momentum_window: int = 20, trend_window: int = 60,
                 vol_short: int = 5, vol_long: int = 20, buy_score: int = 2):
        self.momentum_window = momentum_window
        self.trend_window = trend_window
        self.vol_short = vol_short
        self.vol_long = vol_long
        self.buy_score = buy_score

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        close, volume = df['close'], df['volume']

        f_momentum = close.pct_change(self.momentum_window) > 0
        f_trend = close > close.rolling(self.trend_window).mean()
        f_volume = volume.rolling(self.vol_short).mean() > volume.rolling(self.vol_long).mean()

        score = f_momentum.astype(int) + f_trend.astype(int) + f_volume.astype(int)

        enter = (score >= self.buy_score) & (score.shift(1) < self.buy_score)
        exit_ = (score <= 1) & (score.shift(1) > 1)

        signals = pd.Series(0, index=df.index)
        signals[enter] = 1
        signals[exit_] = -1
        return signals
